
public class ATMCaseStudy {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ATM theATM=new ATM();
		theATM.run();
	}

}
