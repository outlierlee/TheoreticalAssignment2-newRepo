import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
public class Screen extends Frame {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private TextField text;
	public Screen(){
		super("ATM-Screen");
		init();
	}

	private void init() {
		// TODO Auto-generated method stub
		setLayout(new FlowLayout());
		setSize(400,300);
		text=new TextField();
		text.setBounds(10, 10, 100, 50);
		addWindowListener(new WindowAdapter(){
			public void windowClosing(WindowEvent evt){
				setVisible(false);
				dispose();
				System.exit(0);
			}
		});
		setVisible(true);
	}

	public void displayMessageLine(String string) {
		// TODO Auto-generated method stub
		text.setText(string);
	}

	public void displayMessage(String string) {
		// TODO Auto-generated method stub
		text.setText(string);
	}

	public void displayMainMenu() {
		// TODO Auto-generated method stub
		System.out.println("main menu");
		
	}

	public void displayInquiryMenu() {
		// TODO Auto-generated method stub
		System.out.println("displayInquiry menu");
	}

	public void displayWithdrawalMenu() {
		// TODO Auto-generated method stub
		System.out.println("withdrawal menu");
	}

	public void displayDollarAmount(double amount) {
		// TODO Auto-generated method stub
		System.out.printf("$%,.2f", amount);
	}

	public void displayDepositMenu() {
		// TODO Auto-generated method stub
		System.out.println("Deposit menu");
	}

}
