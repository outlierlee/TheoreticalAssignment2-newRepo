
public class Deposit extends Transaction {
	private double amount;
	private Keypad keypad;
	private DepositSlot depositSlot;
	private final static int CANCELED=0;
	public Deposit(int userAccountNumber, Screen atmScreen, BankDatabase atmBankDatabase, Keypad atmKeypad,
			DepositSlot atmDepositSlot) {
		// TODO Auto-generated constructor stub
		super(userAccountNumber,atmScreen,atmBankDatabase);
		keypad=atmKeypad;
		depositSlot=atmDepositSlot;
	}

	@Override
	public void execute() {
		// TODO Auto-generated method stub
		BankDatabase bankDatabase=getBankDatabase();
		Screen screen=getScreen();
		amount=promptForDepositAmount();
		if(amount!=CANCELED){
			screen.displayMessage("Please insert a deposit envelope containing");
			screen.displayDollarAmount(amount);
			boolean envelopeReceived=depositSlot.isEnvelopeReceived();
			if(envelopeReceived){
				screen.displayDepositMenu();
				bankDatabase.credit(getAccountNumber(), amount);
			}else{
				screen.displayMessageLine("you did not insert an"
						+ "envelope,so the ATM has canceled your transaction");
			}
		}else{
			screen.displayMessage("Canceling transaction...");
		}
	}

	private double promptForDepositAmount() {
		// TODO Auto-generated method stub
		Screen screen=getScreen();
		screen.displayMessage("Please enter a deposit amount in"
				+ "CENTS(or 0 to cancel):");
		int input=keypad.getInput();
		if(input==CANCELED){
			return CANCELED;
		}else{
			return (double)input/100;
		}
	}

}
