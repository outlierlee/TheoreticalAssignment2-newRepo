
public class BalanceInquiry extends Transaction {

	public BalanceInquiry(int userAccountNumber, Screen atmScreen, BankDatabase atmBankDatabase) {
		// TODO Auto-generated constructor stub
		super(userAccountNumber,atmScreen,atmBankDatabase);
	}

	@Override
	public void execute() {
		// TODO Auto-generated method stub
		BankDatabase bankDatabase=getBankDatabase();
		Screen screen=getScreen();
		double availableBalance=bankDatabase.getAvailableBalance(getAccountNumber());
		double totalBalance=bankDatabase.getTotalBalance(getAccountNumber());
		screen.displayInquiryMenu();
	}

}
